using System;
using System.Drawing;
using System.Windows.Forms;
using CalzadoJL.Business;

namespace CalzadoJL.Desktop.Forms
{
    public class LoginForm : Form
    {
        private TextBox txtUser, txtPass;
        private Button btnLogin, btnCancel;

        public LoginForm()
        {
            Text = "CalzadoJL - Inicio de sesión";
            ClientSize = new Size(340, 230);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            var title = new Label { Text = "CalzadoJL", Font = new Font("Segoe UI", 18, FontStyle.Bold),
                                    AutoSize = true, Location = new Point(100, 15) };
            var lblUser = new Label { Text = "Usuario:", Location = new Point(30, 70), AutoSize = true };
            txtUser = new TextBox { Location = new Point(110, 66), Width = 190 };
            var lblPass = new Label { Text = "Contraseña:", Location = new Point(30, 110), AutoSize = true };
            txtPass = new TextBox { Location = new Point(110, 106), Width = 190, UseSystemPasswordChar = true };

            btnLogin = new Button { Text = "Ingresar", Location = new Point(110, 160), Width = 90 };
            btnCancel = new Button { Text = "Cancelar", Location = new Point(210, 160), Width = 90 };
            btnLogin.Click += BtnLogin_Click;
            btnCancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };

            Controls.AddRange(new Control[] { title, lblUser, txtUser, lblPass, txtPass, btnLogin, btnCancel });
            AcceptButton = btnLogin;
            CancelButton = btnCancel;
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            var user = new AuthService().Login(txtUser.Text.Trim(), txtPass.Text);
            if (user == null)
            {
                MessageBox.Show("Usuario o contraseña incorrectos.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Session.CurrentUser = user;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
