using System;
using System.Drawing;
using System.Windows.Forms;
using CalzadoJL.Business;
using CalzadoJL.Entity;

namespace CalzadoJL.Desktop.Forms
{
    /// <summary>Ejemplo de uso del formulario base.</summary>
    public class CategoryForm : BaseCrudForm
    {
        private readonly CategoryService _service = new CategoryService();
        private TextBox txtName, txtDescription;
        private int _selectedId;

        public CategoryForm()
        {
            Text = "Categorías";
            PanelCampos.Controls.Add(new Label { Text = "Nombre:", Location = new Point(10, 15), AutoSize = true });
            txtName = new TextBox { Location = new Point(110, 12), Width = 280 };
            PanelCampos.Controls.Add(new Label { Text = "Descripción:", Location = new Point(10, 55), AutoSize = true });
            txtDescription = new TextBox { Location = new Point(110, 52), Width = 280 };
            PanelCampos.Controls.AddRange(new Control[] { txtName, txtDescription });
        }

        protected override void CargarDatos()
        {
            Grid.DataSource = _service.GetAll();
            foreach (var col in new[] { "State", "Products", "StateId" })
                if (Grid.Columns.Contains(col)) Grid.Columns[col].Visible = false;
        }

        protected override void Guardar()
        {
            try
            {
                _service.Save(new Category
                {
                    Id = 0, Name = txtName.Text.Trim(),
                    Description = txtDescription.Text.Trim(), StateId = 1
                });
                Limpiar(); CargarDatos();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        protected override void Editar()
        {
            if (_selectedId == 0) { MessageBox.Show("Seleccione un registro."); return; }
            try
            {
                _service.Save(new Category
                {
                    Id = _selectedId, Name = txtName.Text.Trim(),
                    Description = txtDescription.Text.Trim(), StateId = 1
                });
                Limpiar(); CargarDatos();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        protected override void Eliminar()
        {
            if (_selectedId == 0) { MessageBox.Show("Seleccione un registro."); return; }
            if (MessageBox.Show("¿Eliminar el registro?", "Confirmar", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try { _service.Delete(_selectedId); Limpiar(); CargarDatos(); }
            catch (Exception ex) { MessageBox.Show("No se pudo eliminar: " + ex.Message); }
        }

        protected override void Limpiar()
        {
            _selectedId = 0;
            txtName.Clear();
            txtDescription.Clear();
            txtName.Focus();
        }

        protected override void SeleccionarFila()
        {
            var c = (Category)Grid.CurrentRow.DataBoundItem;
            _selectedId = c.Id;
            txtName.Text = c.Name;
            txtDescription.Text = c.Description;
        }
    }
}
