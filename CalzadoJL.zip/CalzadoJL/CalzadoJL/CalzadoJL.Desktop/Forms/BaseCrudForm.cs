using System;
using System.Drawing;
using System.Windows.Forms;

namespace CalzadoJL.Desktop.Forms
{
    /// <summary>
    /// Formulario base (plantilla) para CRUD. Los formularios hijos heredan de él,
    /// agregan sus campos en PanelCampos y sobrescriben Guardar/Editar/Eliminar/Limpiar/CargarDatos.
    /// </summary>
    public class BaseCrudForm : Form
    {
        protected Panel PanelCampos;
        protected DataGridView Grid;
        protected Button BtnGuardar, BtnEditar, BtnEliminar, BtnLimpiar;

        public BaseCrudForm()
        {
            Text = "Mantenimiento";
            ClientSize = new Size(760, 520);
            StartPosition = FormStartPosition.CenterParent;

            PanelCampos = new Panel { Dock = DockStyle.Top, Height = 170, Padding = new Padding(10) };

            var panelBotones = new FlowLayoutPanel
            {
                Dock = DockStyle.Top, Height = 45, Padding = new Padding(10, 6, 0, 0)
            };
            BtnGuardar = new Button { Text = "Guardar", Width = 100 };
            BtnEditar = new Button { Text = "Editar", Width = 100 };
            BtnEliminar = new Button { Text = "Eliminar", Width = 100 };
            BtnLimpiar = new Button { Text = "Limpiar", Width = 100 };
            panelBotones.Controls.AddRange(new Control[] { BtnGuardar, BtnEditar, BtnEliminar, BtnLimpiar });

            Grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            // El orden importa: Fill primero, luego los Top
            Controls.Add(Grid);
            Controls.Add(panelBotones);
            Controls.Add(PanelCampos);

            BtnGuardar.Click += (s, e) => Guardar();
            BtnEditar.Click += (s, e) => Editar();
            BtnEliminar.Click += (s, e) => Eliminar();
            BtnLimpiar.Click += (s, e) => Limpiar();
            Grid.CellClick += (s, e) => { if (e.RowIndex >= 0) SeleccionarFila(); };
            Load += (s, e) => { if (!DesignMode) CargarDatos(); };
        }

        protected virtual void Guardar() { }
        protected virtual void Editar() { }
        protected virtual void Eliminar() { }
        protected virtual void Limpiar() { }
        protected virtual void CargarDatos() { }
        protected virtual void SeleccionarFila() { }
    }
}
