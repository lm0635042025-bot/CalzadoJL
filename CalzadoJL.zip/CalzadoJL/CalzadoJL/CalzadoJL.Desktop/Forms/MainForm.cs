using System;
using System.Windows.Forms;

namespace CalzadoJL.Desktop.Forms
{
    public class MainForm : Form
    {
        public MainForm()
        {
            Text = "CalzadoJL - Sistema de inventario y ventas";
            WindowState = FormWindowState.Maximized;
            IsMdiContainer = true;

            var menu = new MenuStrip();
            var mantenimiento = new ToolStripMenuItem("Mantenimiento");
            var categorias = new ToolStripMenuItem("Categorías");
            categorias.Click += (s, e) => new CategoryForm { MdiParent = this }.Show();
            mantenimiento.DropDownItems.Add(categorias);

            var salir = new ToolStripMenuItem("Salir");
            salir.Click += (s, e) => Close();

            menu.Items.Add(mantenimiento);
            menu.Items.Add(salir);
            MainMenuStrip = menu;
            Controls.Add(menu);
        }
    }
}
