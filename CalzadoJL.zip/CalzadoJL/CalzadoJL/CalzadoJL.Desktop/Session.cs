using CalzadoJL.Entity;

namespace CalzadoJL.Desktop
{
    public static class Session
    {
        public static User CurrentUser { get; set; }
    }
}
