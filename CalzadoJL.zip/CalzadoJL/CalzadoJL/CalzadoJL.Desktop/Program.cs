using System;
using System.Windows.Forms;
using CalzadoJL.Business;
using CalzadoJL.Desktop.Forms;

namespace CalzadoJL.Desktop
{
    internal static class Program
    {
        /// <summary>Punto de entrada principal para la aplicación.</summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try { new AuthService().Initialize(); }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo conectar a la base de datos:\n" + ex.Message);
                return;
            }

            using (var login = new LoginForm())
            {
                if (login.ShowDialog() == DialogResult.OK)
                    Application.Run(new MainForm());
            }
        }
    }
}
