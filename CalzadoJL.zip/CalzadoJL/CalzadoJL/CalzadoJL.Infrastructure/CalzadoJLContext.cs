using System.Linq;
using CalzadoJL.Entity;
using Microsoft.EntityFrameworkCore;

namespace CalzadoJL.Infrastructure
{
    public class CalzadoJLContext : DbContext
    {
        public CalzadoJLContext(DbContextOptions<CalzadoJLContext> options) : base(options) { }

        public DbSet<State> States { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Purchase> Purchases { get; set; }
        public DbSet<PurchaseDetail> PurchaseDetails { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<SaleDetail> SaleDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            foreach (var fk in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
                fk.DeleteBehavior = DeleteBehavior.Restrict;

            modelBuilder.Entity<State>().HasData(
                new State { Id = 1, Name = "Activo" },
                new State { Id = 2, Name = "Inactivo" });
        }
    }
}
