using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace CalzadoJL.Infrastructure.Repositories
{
    public class Repository<T> : IRepository<T> where T : class
    {
        protected readonly CalzadoJLContext _context;
        protected readonly DbSet<T> _set;

        public Repository(CalzadoJLContext context)
        {
            _context = context;
            _set = context.Set<T>();
        }

        public virtual List<T> GetAll() => _set.AsNoTracking().ToList();
        public virtual T GetById(int id) => _set.Find(id);

        public virtual void Add(T entity)
        {
            _set.Add(entity);
            _context.SaveChanges();
        }

        public virtual void Update(T entity)
        {
            _set.Update(entity);
            _context.SaveChanges();
        }

        public virtual void Delete(int id)
        {
            var entity = _set.Find(id);
            if (entity == null) return;
            _set.Remove(entity);
            _context.SaveChanges();
        }
    }
}
