using Microsoft.EntityFrameworkCore;

namespace CalzadoJL.Infrastructure
{
    public static class DbContextFactory
    {
        public const string ConnectionString =
            "Server=DESKTOP-B36RIC5\\SQLEXPRESS;Database=CalzadoJLDB;Trusted_Connection=True;TrustServerCertificate=True;";

        public static CalzadoJLContext Create()
        {
            var options = new DbContextOptionsBuilder<CalzadoJLContext>()
                .UseSqlServer(ConnectionString)
                .Options;
            return new CalzadoJLContext(options);
        }
    }
}
