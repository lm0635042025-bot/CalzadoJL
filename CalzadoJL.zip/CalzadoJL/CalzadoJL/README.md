# CalzadoJL
Sistema de inventario (ingreso) y venta al detalle de calzado. Arquitectura N-Capas:

| Proyecto | Capa |
|---|---|
| CalzadoJL.Entity | Dominio (entidades + Data Annotations) |
| CalzadoJL.Infrastructure | Acceso a datos (EF Core, repositorios) |
| CalzadoJL.Business | Lógica de negocio |
| CalzadoJL.Desktop | Presentación WinForms |

Usuario inicial: `admin` / `admin123`
