using System;
using System.Collections.Generic;
using CalzadoJL.Entity;
using CalzadoJL.Infrastructure;
using CalzadoJL.Infrastructure.Repositories;

namespace CalzadoJL.Business
{
    public class CategoryService
    {
        public List<Category> GetAll()
        {
            using (var db = DbContextFactory.Create())
                return new Repository<Category>(db).GetAll();
        }

        public void Save(Category c)
        {
            if (string.IsNullOrWhiteSpace(c.Name))
                throw new Exception("El nombre es obligatorio.");

            using (var db = DbContextFactory.Create())
            {
                var repo = new Repository<Category>(db);
                if (c.Id == 0) repo.Add(c); else repo.Update(c);
            }
        }

        public void Delete(int id)
        {
            using (var db = DbContextFactory.Create())
                new Repository<Category>(db).Delete(id);
        }
    }
}
