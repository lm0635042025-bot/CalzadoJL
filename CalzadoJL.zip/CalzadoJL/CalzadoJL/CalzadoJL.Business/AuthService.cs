using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using CalzadoJL.Entity;
using CalzadoJL.Infrastructure;

namespace CalzadoJL.Business
{
    public class AuthService
    {
        public static string Hash(string text)
        {
            using (var sha = SHA256.Create())
                return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(text)));
        }

        /// <summary>Crea la BD y el usuario admin/admin123 si no existen.</summary>
        public void Initialize()
        {
            using (var db = DbContextFactory.Create())
            {
                db.Database.EnsureCreated();
                if (!db.Users.Any())
                {
                    db.Users.Add(new User
                    {
                        Username = "admin",
                        PasswordHash = Hash("admin123"),
                        FullName = "Administrador",
                        Role = "Administrador",
                        StateId = 1
                    });
                    db.SaveChanges();
                }
            }
        }

        public User Login(string username, string password)
        {
            using (var db = DbContextFactory.Create())
            {
                var hash = Hash(password);
                return db.Users.FirstOrDefault(u =>
                    u.Username == username && u.PasswordHash == hash && u.StateId == 1);
            }
        }
    }
}
