using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CalzadoJL.Entity
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(50)]
        public string Username { get; set; }

        [Required, StringLength(200)]
        public string PasswordHash { get; set; }

        [Required, StringLength(100)]
        public string FullName { get; set; }

        [Required, StringLength(30)]
        public string Role { get; set; } // Administrador / Vendedor

        [Required]
        public int StateId { get; set; }

        [ForeignKey(nameof(StateId))]
        public virtual State State { get; set; }
    }
}
