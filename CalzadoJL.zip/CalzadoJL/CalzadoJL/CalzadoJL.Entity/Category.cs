using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CalzadoJL.Entity
{
    public class Category
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la categoría es obligatorio")]
        [StringLength(80)]
        public string Name { get; set; }

        [StringLength(200)]
        public string Description { get; set; }

        [Required]
        public int StateId { get; set; }

        [ForeignKey(nameof(StateId))]
        public virtual State State { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }
}
