using System.ComponentModel.DataAnnotations;

namespace CalzadoJL.Entity
{
    public class Customer
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string FullName { get; set; }

        [StringLength(20)]
        public string Document { get; set; }

        [StringLength(20)]
        public string Phone { get; set; }
    }
}
