using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CalzadoJL.Entity
{
    public class Product
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(30)]
        public string Code { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; }

        [StringLength(60)]
        public string Brand { get; set; }

        [Required, StringLength(10)]
        public string Size { get; set; }

        [StringLength(30)]
        public string Color { get; set; }

        [Required, Column(TypeName = "decimal(18,2)")]
        public decimal PurchasePrice { get; set; }

        [Required, Column(TypeName = "decimal(18,2)")]
        public decimal SalePrice { get; set; }

        [Required]
        public int Stock { get; set; }

        [Required]
        public int CategoryId { get; set; }

        [Required]
        public int StateId { get; set; }

        [ForeignKey(nameof(CategoryId))]
        public virtual Category Category { get; set; }

        [ForeignKey(nameof(StateId))]
        public virtual State State { get; set; }
    }
}
