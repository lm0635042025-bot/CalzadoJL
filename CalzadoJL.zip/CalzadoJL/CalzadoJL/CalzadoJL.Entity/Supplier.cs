using System.ComponentModel.DataAnnotations;

namespace CalzadoJL.Entity
{
    public class Supplier
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; }

        [StringLength(20)]
        public string Phone { get; set; }

        [StringLength(100), EmailAddress]
        public string Email { get; set; }
    }
}
