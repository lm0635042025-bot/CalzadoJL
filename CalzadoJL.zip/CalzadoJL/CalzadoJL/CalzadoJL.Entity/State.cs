using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CalzadoJL.Entity
{
    /// <summary>Estado general (Activo, Inactivo, etc.).</summary>
    public class State
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del estado es obligatorio")]
        [StringLength(50)]
        public string Name { get; set; }

        public virtual ICollection<Category> Categories { get; set; }
        public virtual ICollection<Product> Products { get; set; }
        public virtual ICollection<User> Users { get; set; }
    }
}
